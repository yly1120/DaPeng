#ifndef _ESP8266_H_
#define _ESP8266_H_


#include "main.h"
#include "usart.h"
#include <string.h>
#include "oled.h"
#include "onenet.h"


#define REV_OK		0	//接收完成标志
#define REV_WAIT	1	//接收未完成标志


void ESP8266_Init(void);

void ESP8266_Clear(void);

_Bool ESP8266_SendCmd(char *cmd, char *res);

void ESP8266_SendData(unsigned char *data, unsigned short len);

unsigned char *ESP8266_GetIPD(unsigned short timeOut);

void ESP8266_EN(void); 		// 初始化前调用这个

#endif
